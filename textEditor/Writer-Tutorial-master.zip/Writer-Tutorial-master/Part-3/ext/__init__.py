__all__ = ["find","wordcount"]
